package Model;

public class Reaction {
}
