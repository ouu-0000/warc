package Model;

public class Comment {
}
