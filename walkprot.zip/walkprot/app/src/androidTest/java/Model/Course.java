package Model;

public class Course {
}
