package Model;

public class Road {
}
