package Model;

public class Tag {
}
