package Model;

public class Favorite {
}
