package Service;

public class SearchCourseService {
}
