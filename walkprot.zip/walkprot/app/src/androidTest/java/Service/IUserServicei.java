package Service;

public class IUserServicei {
    public void CreateUser(String name) {

    }
}
