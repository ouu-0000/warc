package Service;

public class UserService {
    public ClientUserRepository repos;
    public void CreateUser(String name){

    }
}
