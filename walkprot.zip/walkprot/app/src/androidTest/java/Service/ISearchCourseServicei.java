package Service;

public class ISearchCourseServicei {
}
