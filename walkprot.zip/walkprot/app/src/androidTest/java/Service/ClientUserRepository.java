package Service;

public class ClientUserRepository {
    public String id;
    public String name;
    public String GetUserID(){
        return this.id;
    }
    public String GetUserName(){
        return this.name;
    }
}
