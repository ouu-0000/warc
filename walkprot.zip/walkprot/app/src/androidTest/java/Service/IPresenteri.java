package Service;

import Model.Course;
import Model.User;

public class IPresenteri {
    public Boolean Success(User user){
        return Boolean.TRUE;
    }
    public Boolean Success(Course course){
        return Boolean.TRUE;
    }

}
