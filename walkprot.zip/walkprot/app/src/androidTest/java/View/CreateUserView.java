package View;

import Service.IUserServicei;

public class CreateUserView {
    public String name;
    public void CreateUser(){
        IUserServicei iuserservicei = new IUserServicei();
        iuserservicei.CreateUser(this.name);
    }
}
