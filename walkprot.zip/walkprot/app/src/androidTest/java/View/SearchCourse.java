package View;

public class SearchCourse {
}
