package View;

public class Menu {
}
