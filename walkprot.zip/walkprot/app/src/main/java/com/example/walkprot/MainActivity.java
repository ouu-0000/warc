package com.example.walkprot;

import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import View.*;
import Service.*;


public class MainActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CreateUserView createuserview = new CreateUserView();
        IUserServicei iuserservicei = new IUserServicei();
        IPresenteri ipresenteri = new IPresenter();
        Presenter presenter = new Presenter();
        setContentView(R.layout.createuser);
        Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(click);
        EditText edittext = findViewById(R.id.edittext);
    }
    public View.OnClickListener click = new View.OnClickListener(){
        @Override
        public void onClick(View view){
            SpannableStringBuilder sb = (SpannableStringBuilder)edittext.getText();
            createuserview.name = sb.toString();
            createuserview.CreateUser(createuserview.name);
        }
    };
}